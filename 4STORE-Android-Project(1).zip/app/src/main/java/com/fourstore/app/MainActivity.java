package com.fourstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    int blue = Color.rgb(22,139,255);
    LinearLayout root;

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,13,24));
        getWindow().setNavigationBarColor(Color.rgb(8,13,24));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,32,24,24);
        root.setBackgroundColor(Color.rgb(8,13,24));
        root.setGravity(Gravity.TOP);
        setContentView(root);

        TextView logo = text("4STORE", 32, Color.WHITE, true);
        root.addView(logo);
        TextView sub = text("متجر الإلكترونيات", 16, blue, true);
        root.addView(sub);

        TextView intro = text("أهلاً بك في 4STORE\nمكانك لعرض وشراء الهواتف واللابتوبات والإلكترونيات.", 18, Color.WHITE, false);
        intro.setPadding(0,36,0,28);
        root.addView(intro);

        addSection("الأقسام");
        addButton("الهواتف");
        addButton("اللابتوبات");
        addButton("الإكسسوارات");
        addSection("الإعلانات");
        TextView empty = text("لا توجد إعلانات حالياً.\nسيتم عرض المنتجات هنا بعد ربط قاعدة البيانات.", 15, Color.LTGRAY, false);
        empty.setPadding(0,12,0,20);
        root.addView(empty);
        Button post = new Button(this);
        post.setText("أضف إعلانك");
        post.setOnClickListener(v -> Toast.makeText(this, "سيتم تفعيل نشر الإعلانات والحسابات في المرحلة التالية", Toast.LENGTH_LONG).show());
        root.addView(post);
    }
    void addSection(String s) {
        TextView t = text(s, 21, Color.WHITE, true);
        t.setPadding(0,24,0,8);
        root.addView(t);
    }
    void addButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setOnClickListener(v -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
        root.addView(b);
    }
}
